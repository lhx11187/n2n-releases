##在斐讯N1上编译，系统为Armbian即debian linux内核5.0.0，架构ARM64即aarch64
同步最新源码https://github.com/ntop/n2n
编译日期20190704
版本v.2.5.0 for Debian 9.9
编译人 黑鸭子


