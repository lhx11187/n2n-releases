﻿原贴位置 http://www.tcpfile.com:12345/n2n/  

在树莓派Raspbian系统上编译，可以用于其它ARM架构的linux系统上
