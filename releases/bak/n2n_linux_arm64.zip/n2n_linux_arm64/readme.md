##在斐讯N1上编译，系统为Armbian即debian linux内核5.0.0，架构ARM64即aarch64


