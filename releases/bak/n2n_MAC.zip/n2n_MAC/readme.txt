Mac users need to install tuntag like this:

https://github.com/ntop/n2n/blob/dev/doc/n2n_on_MacOS.txt